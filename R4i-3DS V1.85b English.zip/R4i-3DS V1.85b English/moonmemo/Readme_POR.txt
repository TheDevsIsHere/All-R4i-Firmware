﻿
Copie esta pasta na raiz do seu cartão SD (e não no interior da pasta "/moonshl2") para ativar a função Bloco de Notas.
Mantenha pressionado L ou R e toque na Touch Screen ou então abra o menu principal com o botão START e selecione "Abrir Bloco de Notas" para iniciá-lo.

Para obter mais informações, por favor veja a seção "Bloco de Notas" do manual.

~Traduzido por Axel-MaV